<#
.SYNOPSIS
    Registers the CapFrameX Vulkan layers of this folder, which draw the in-game overlay in
    Vulkan games.
.DESCRIPTION
    Staged as vulkan\Register-CapFrameXVulkanLayer.ps1 beside the x64 layer; the x86 layer lives
    in vulkan\x86. The portable CapFrameX runs it when the user agrees at startup; the installer
    registers its layers itself and does not ship this script.

    The Vulkan loader reads implicit layers from HKLM\SOFTWARE\Khronos\Vulkan\ImplicitLayers, one
    registry view per bitness: the x64 manifest goes into the 64-bit view, the x86 manifest into
    WOW6432Node. It identifies a layer by the NAME inside its manifest, so a second CapFrameX
    registration competes with this one. Every other enabled CapFrameX registration in HKLM is
    therefore disabled (DWORD 1, not deleted: an installed CapFrameX keeps its value, and
    repairing that installation enables it again). CapFrameX registrations in HKCU are removed:
    the loader ignores HKCU for elevated games, and HKCU is not split by bitness, so an entry there
    disables the layer for the other bitness.

    Only CapFrameX registry values are changed; no file is written. Requires an elevated
    PowerShell and never starts UAC itself. Exit code 0 means the layers are registered.
.PARAMETER ValidateOnly
    Check the layer files and show the planned changes without writing to the registry.
.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File .\vulkan\Register-CapFrameXVulkanLayer.ps1
#>
[CmdletBinding()]
param(
    [switch]$ValidateOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$registryPath = 'SOFTWARE\Khronos\Vulkan\ImplicitLayers'
$layerName = 'VK_LAYER_CAPFRAMEX_overlay'
$manifestFileName = 'cfx_osd_vklayer_v1.json'

# Console streams, so that CapFrameX, which redirects them, logs every line. CapFrameX reads
# them as UTF-8; the console code page would garble paths with non-ASCII characters.
if ([Console]::IsOutputRedirected) {
    try { [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false) } catch { }
}
function Write-Line([string]$Text) { [Console]::Out.WriteLine($Text) }

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    finally { $identity.Dispose() }
}

function Get-JsonProperty($Object, [string]$Name) {
    if ($null -eq $Object) { return $null }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { return $null }
    return $property.Value
}

# $true when the manifest declares the CapFrameX layer, $false when it declares another one,
# $null when it cannot be read.
function Test-ManifestDeclaresLayer([string]$Path) {
    try {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
        $document = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        $layers = @(Get-JsonProperty $document 'layer') + @(Get-JsonProperty $document 'layers')
        foreach ($layer in $layers) {
            if ((Get-JsonProperty $layer 'name') -ceq $layerName) { return $true }
        }
        return $false
    }
    catch { return $null }
}

# A registration whose manifest is gone or damaged still counts as CapFrameX's by its file name,
# as for the installer's purge and the Info tab.
function Test-CapFrameXRegistration([string]$Name) {
    $declares = Test-ManifestDeclaresLayer $Name
    if ($null -ne $declares) { return $declares }
    try { return [IO.Path]::GetFileName($Name) -like 'cfx_osd_vklayer*.json' }
    catch { return $false }
}

function Get-LayerPayload([string]$Folder, [string]$View, [int]$ExpectedMachine) {
    $manifest = Join-Path $Folder $manifestFileName
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw "Layer manifest missing: $manifest" }
    $manifest = (Get-Item -LiteralPath $manifest).FullName
    $layer = Get-JsonProperty (Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json) 'layer'
    if ((Get-JsonProperty $layer 'name') -cne $layerName) { throw "Not a CapFrameX layer manifest: $manifest" }
    $library = [string](Get-JsonProperty $layer 'library_path')
    if ([string]::IsNullOrWhiteSpace($library) -or [IO.Path]::IsPathRooted($library)) {
        throw "The layer DLL path must be relative: $manifest"
    }
    $dll = [IO.Path]::GetFullPath((Join-Path $Folder $library))
    $expectedDll = [IO.Path]::GetFullPath((Join-Path $Folder 'cfx_osd_vklayer.dll'))
    if (-not $dll.Equals($expectedDll, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $dll -PathType Leaf)) {
        throw "The manifest must reference its adjacent cfx_osd_vklayer.dll: $manifest"
    }
    $stream = [IO.File]::OpenRead($dll)
    $reader = New-Object IO.BinaryReader($stream)
    try {
        if ($stream.Length -lt 64 -or $reader.ReadUInt16() -ne 0x5A4D) { throw "Invalid PE DLL: $dll" }
        $stream.Position = 0x3C
        $peOffset = $reader.ReadInt32()
        if ($peOffset -lt 64 -or $peOffset -gt $stream.Length - 6) { throw "Invalid PE header offset: $dll" }
        $stream.Position = $peOffset
        if ($reader.ReadUInt32() -ne 0x00004550 -or $reader.ReadUInt16() -ne $ExpectedMachine) {
            throw "Wrong DLL architecture for ${View}: $dll"
        }
    }
    finally { $reader.Dispose(); $stream.Dispose() }
    [pscustomobject]@{ View = $View; Manifest = $manifest; Dll = $dll }
}

function Open-BaseKey([string]$Hive, [string]$View) {
    [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::$Hive, [Microsoft.Win32.RegistryView]::$View)
}

# Data is the DWORD the loader reads (0 = enabled), $null for a value of another type.
function Get-Registration([string]$Hive, [string]$View, [string]$Name) {
    $base = Open-BaseKey $Hive $View
    try {
        $key = $base.OpenSubKey($registryPath, $false)
        try {
            $exists = $null -ne $key -and @($key.GetValueNames()) -contains $Name
            $data = $null
            if ($exists -and $key.GetValueKind($Name) -eq [Microsoft.Win32.RegistryValueKind]::DWord) { $data = [int]$key.GetValue($Name) }
            [pscustomobject]@{ Exists = $exists; Data = $data }
        }
        finally { if ($null -ne $key) { $key.Dispose() } }
    }
    finally { $base.Dispose() }
}

function Get-CapFrameXRegistrations([string]$Hive, [string]$View) {
    $base = Open-BaseKey $Hive $View
    try {
        $key = $base.OpenSubKey($registryPath, $false)
        try {
            if ($null -eq $key) { return }
            foreach ($name in $key.GetValueNames()) {
                if (-not (Test-CapFrameXRegistration $name)) { continue }
                $data = $null
                if ($key.GetValueKind($name) -eq [Microsoft.Win32.RegistryValueKind]::DWord) { $data = [int]$key.GetValue($name) }
                [pscustomobject]@{ Hive = $Hive; View = $View; Name = $name; Data = $data }
            }
        }
        finally { if ($null -ne $key) { $key.Dispose() } }
    }
    finally { $base.Dispose() }
}

function Set-Registration([string]$Hive, [string]$View, [string]$Name, [bool]$Exists, $Data) {
    $base = Open-BaseKey $Hive $View
    try {
        $key = if ($Exists) { $base.CreateSubKey($registryPath) } else { $base.OpenSubKey($registryPath, $true) }
        try {
            if ($null -eq $key) { return }
            if ($Exists) { $key.SetValue($Name, [int]$Data, [Microsoft.Win32.RegistryValueKind]::DWord) }
            else { $key.DeleteValue($Name, $false) }
            $key.Flush()
        }
        finally { if ($null -ne $key) { $key.Dispose() } }
    }
    finally { $base.Dispose() }
}

function New-Change([string]$Hive, [string]$View, [string]$Name, $Before, [bool]$AfterExists, $AfterData) {
    [pscustomobject]@{ Hive = $Hive; View = $View; Name = $Name;
        BeforeExists = $Before.Exists; BeforeData = $Before.Data; AfterExists = $AfterExists; AfterData = $AfterData }
}

try {
    $payloads = @(
        Get-LayerPayload $PSScriptRoot 'Registry64' 0x8664
        Get-LayerPayload (Join-Path $PSScriptRoot 'x86') 'Registry32' 0x014C
    )

    $changes = New-Object 'System.Collections.Generic.List[object]'
    foreach ($payload in $payloads) {
        Write-Line "$($payload.View): $($payload.Manifest)"
        foreach ($current in @(Get-CapFrameXRegistrations 'LocalMachine' $payload.View)) {
            if ($current.Name -ine $payload.Manifest -and $current.Data -eq 0) {
                $changes.Add((New-Change 'LocalMachine' $payload.View $current.Name ([pscustomobject]@{ Exists = $true; Data = 0 }) $true 1))
            }
        }
        $existing = Get-Registration 'LocalMachine' $payload.View $payload.Manifest
        if (-not $existing.Exists -or $existing.Data -ne 0) {
            $changes.Add((New-Change 'LocalMachine' $payload.View $payload.Manifest $existing $true 0))
        }
    }
    # HKCU\Software is shared by both views, so one of them covers it.
    foreach ($current in @(Get-CapFrameXRegistrations 'CurrentUser' 'Registry64')) {
        $changes.Add((New-Change 'CurrentUser' 'Registry64' $current.Name ([pscustomobject]@{ Exists = $true; Data = $current.Data }) $false $null))
    }

    foreach ($change in $changes) {
        $action = if (-not $change.AfterExists) { 'remove' } elseif ($change.AfterData -eq 0) { 'enable' } else { 'disable' }
        Write-Line "  $action $($change.Hive) $($change.View): $($change.Name)"
    }
    if ($ValidateOnly) { Write-Line 'Validation only: the registry was not changed.'; exit 0 }
    if ($changes.Count -eq 0) { Write-Line 'The layers of this folder are already registered; nothing changed.'; exit 0 }
    if (-not (Test-Administrator)) {
        throw 'Run this script from an elevated PowerShell (Run as administrator). Nothing was changed.'
    }

    $applied = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($change in $changes) {
            $applied.Add($change)
            Set-Registration $change.Hive $change.View $change.Name $change.AfterExists $change.AfterData
        }
        foreach ($change in $changes) {
            $actual = Get-Registration $change.Hive $change.View $change.Name
            if ($actual.Exists -ne $change.AfterExists -or ($actual.Exists -and $actual.Data -ne $change.AfterData)) {
                throw "Registration verification failed: $($change.Name)"
            }
        }
    }
    catch {
        $failure = $_
        # The removed HKCU values are not restored: they are what breaks the layer.
        for ($index = $applied.Count - 1; $index -ge 0; $index--) {
            $change = $applied[$index]
            if ($change.Hive -ne 'LocalMachine') { continue }
            try { Set-Registration $change.Hive $change.View $change.Name $change.BeforeExists $change.BeforeData }
            catch { [Console]::Error.WriteLine("Rollback failed for $($change.Name): $($_.Exception.Message)") }
        }
        throw $failure
    }

    Write-Line 'Registration verified. Restart running Vulkan games to load the layer.'
    exit 0
}
catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}

# SIG # Begin signature block
# MIIplgYJKoZIhvcNAQcCoIIphzCCKYMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCurG+bbq6+wrGj
# qbzt9Cuu5NedI3sshvt2wIKSGBmPl6CCDakwgga5MIIEoaADAgECAhEAmaOACiZV
# O2Wr3G6EprPqOTANBgkqhkiG9w0BAQwFADCBgDELMAkGA1UEBhMCUEwxIjAgBgNV
# BAoTGVVuaXpldG8gVGVjaG5vbG9naWVzIFMuQS4xJzAlBgNVBAsTHkNlcnR1bSBD
# ZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEkMCIGA1UEAxMbQ2VydHVtIFRydXN0ZWQg
# TmV0d29yayBDQSAyMB4XDTIxMDUxOTA1MzIxOFoXDTM2MDUxODA1MzIxOFowVjEL
# MAkGA1UEBhMCUEwxITAfBgNVBAoTGEFzc2VjbyBEYXRhIFN5c3RlbXMgUy5BLjEk
# MCIGA1UEAxMbQ2VydHVtIENvZGUgU2lnbmluZyAyMDIxIENBMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAnSPPBDAjO8FGLOczcz5jXXp1ur5cTbq96y34
# vuTmflN4mSAfgLKTvggv24/rWiVGzGxT9YEASVMw1Aj8ewTS4IndU8s7VS5+djSo
# McbvIKck6+hI1shsylP4JyLvmxwLHtSworV9wmjhNd627h27a8RdrT1PH9ud0IF+
# njvMk2xqbNTIPsnWtw3E7DmDoUmDQiYi/ucJ42fcHqBkbbxYDB7SYOouu9Tj1yHI
# ohzuC8KNqfcYf7Z4/iZgkBJ+UFNDcc6zokZ2uJIxWgPWXMEmhu1gMXgv8aGUsRda
# CtVD2bSlbfsq7BiqljjaCun+RJgTgFRCtsuAEw0pG9+FA+yQN9n/kZtMLK+Wo837
# Q4QOZgYqVWQ4x6cM7/G0yswg1ElLlJj6NYKLw9EcBXE7TF3HybZtYvj9lDV2nT8m
# FSkcSkAExzd4prHwYjUXTeZIlVXqj+eaYqoMTpMrfh5MCAOIG5knN4Q/JHuurfTI
# 5XDYO962WZayx7ACFf5ydJpoEowSP07YaBiQ8nXpDkNrUA9g7qf/rCkKbWpQ5bou
# fUnq1UiYPIAHlezf4muJqxqIns/kqld6JVX8cixbd6PzkDpwZo4SlADaCi2JSplK
# ShBSND36E/ENVv8urPS0yOnpG4tIoBGxVCARPCg1BnyMJ4rBJAcOSnAWd18Jx5n8
# 58JSqPECAwEAAaOCAVUwggFRMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFN10
# XUwA23ufoHTKsW73PMAywHDNMB8GA1UdIwQYMBaAFLahVDkCw6A/joq8+tT4HKbR
# Og79MA4GA1UdDwEB/wQEAwIBBjATBgNVHSUEDDAKBggrBgEFBQcDAzAwBgNVHR8E
# KTAnMCWgI6Ahhh9odHRwOi8vY3JsLmNlcnR1bS5wbC9jdG5jYTIuY3JsMGwGCCsG
# AQUFBwEBBGAwXjAoBggrBgEFBQcwAYYcaHR0cDovL3N1YmNhLm9jc3AtY2VydHVt
# LmNvbTAyBggrBgEFBQcwAoYmaHR0cDovL3JlcG9zaXRvcnkuY2VydHVtLnBsL2N0
# bmNhMi5jZXIwOQYDVR0gBDIwMDAuBgRVHSAAMCYwJAYIKwYBBQUHAgEWGGh0dHA6
# Ly93d3cuY2VydHVtLnBsL0NQUzANBgkqhkiG9w0BAQwFAAOCAgEAdYhYD+WPUCia
# U58Q7EP89DttyZqGYn2XRDhJkL6P+/T0IPZyxfxiXumYlARMgwRzLRUStJl490L9
# 4C9LGF3vjzzH8Jq3iR74BRlkO18J3zIdmCKQa5LyZ48IfICJTZVJeChDUyuQy6rG
# DxLUUAsO0eqeLNhLVsgw6/zOfImNlARKn1FP7o0fTbj8ipNGxHBIutiRsWrhWM2f
# 8pXdd3x2mbJCKKtl2s42g9KUJHEIiLni9ByoqIUul4GblLQigO0ugh7bWRLDm0Cd
# Y9rNLqyA3ahe8WlxVWkxyrQLjH8ItI17RdySaYayX3PhRSC4Am1/7mATwZWwSD+B
# 7eMcZNhpn8zJ+6MTyE6YoEBSRVrs0zFFIHUR08Wk0ikSf+lIe5Iv6RY3/bFAEloM
# U+vUBfSouCReZwSLo8WdrDlPXtR0gicDnytO7eZ5827NS2x7gCBibESYkOh1/w1t
# VxTpV2Na3PR7nxYVlPu1JPoRZCbH86gc96UTvuWiOruWmyOEMLOGGniR+x+zPF/2
# DaGgK2W1eEJfo2qyrBNPvF7wuAyQfiFXLwvWHamoYtPZo0LHuH8X3n9C+xN4YaNj
# t2ywzOr+tKyEVAotnyU9vyEVOaIYMk3IeBrmFnn0gbKeTTyYeEEUz/Qwt4HOUBCr
# W602NCmvO1nm+/80nLy5r0AZvCQxaQ4wggboMIIE0KADAgECAhAjt54rD9+c9X2V
# c88whsMLMA0GCSqGSIb3DQEBCwUAMFYxCzAJBgNVBAYTAlBMMSEwHwYDVQQKExhB
# c3NlY28gRGF0YSBTeXN0ZW1zIFMuQS4xJDAiBgNVBAMTG0NlcnR1bSBDb2RlIFNp
# Z25pbmcgMjAyMSBDQTAeFw0yNjA5MTgwNzI0NThaFw0yNzA5MTgwNzI0NTdaMIGN
# MQswCQYDVQQGEwJERTEWMBQGA1UECAwNTmllZGVyc2FjaHNlbjEQMA4GA1UEBwwH
# R2FyYnNlbjEeMBwGA1UECgwVT3BlbiBTb3VyY2UgRGV2ZWxvcGVyMTQwMgYDVQQD
# DCtPcGVuIFNvdXJjZSBEZXZlbG9wZXIgTWFyayBEYW5pZWwgRmFuZ21leWVyMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3U8B2aDfbRz/ZyaMdlaMYReo
# xkLCtrJjiEsQL1KG1tA2Krue0WUhmcZx/tdJrgG9oTk+8EEA4yebHr03d3PmyVI3
# 5hzUJUoPsPKL1Fe0zEmfJEvNNIrTxBlzOiKUCx1q6ofplfykB97Tg1tsMamVQkmR
# 7XWRLby+77AAEdbSwPmeD5BVuSaRSZdhuz457r9CkKDtsaI5dUK9wtdDCN8A+htM
# 9oOptExDstqQaFgB017DusKumC5ERZpcMFVv2b0l7v65WyGq2+SpAzdhZSY5EhO4
# tk9XqKfFE1fUQb/8Vw6Wx5hzZRKGoJvpu4Q36KnOhg2qMj7Rpmvfxu39TosnQcje
# L1kJnfE/T6KYiuoNXCvRhdxl3cDR45H3V+wQoerxmZU+rehj/fKq4QlW0FiijwBD
# HVn3IOMazUkK/2BFtcszr9nb5vm7F0vmgkfEGDy0WvUuxhv18gfp2G7tjpfmcmt4
# vlI5BF99buOfdAdxVHX453fv/7MhTXj3oaJLjDts/or4JWj8w5sydrnZeQ1+nlr9
# NKzQ1D8siR3axR63ShScwNKtaGCdu9U3h/lsIqTogSGsPaxbZjhu6lB4xirogrqK
# sVt+KgLQW3y9VX1W7ZmUdR12bSq8L2CFBBc1Va1YSYJkwE5Kajg4xPNFmSD62Tbe
# 1yOEdC02dEMb74LJqqUCAwEAAaOCAXgwggF0MAwGA1UdEwEB/wQCMAAwPQYDVR0f
# BDYwNDAyoDCgLoYsaHR0cDovL2Njc2NhMjAyMS5jcmwuY2VydHVtLnBsL2Njc2Nh
# MjAyMS5jcmwwcwYIKwYBBQUHAQEEZzBlMCwGCCsGAQUFBzABhiBodHRwOi8vY2Nz
# Y2EyMDIxLm9jc3AtY2VydHVtLmNvbTA1BggrBgEFBQcwAoYpaHR0cDovL3JlcG9z
# aXRvcnkuY2VydHVtLnBsL2Njc2NhMjAyMS5jZXIwHwYDVR0jBBgwFoAU3XRdTADb
# e5+gdMqxbvc8wDLAcM0wHQYDVR0OBBYEFMWeUhW0fgk/LuogyN7c8RH9XsIWMEsG
# A1UdIAREMEIwCAYGZ4EMAQQBMDYGCyqEaAGG9ncCBQEEMCcwJQYIKwYBBQUHAgEW
# GWh0dHBzOi8vd3d3LmNlcnR1bS5wbC9DUFMwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# DgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCFKbaFdF3aEB5Npeph
# zOk8BvsqYF5zfLJ1sHuCgKDybKUujEuRi6thkta/6Hgr4mPigjBRr2dJ8Kw20ldC
# wnd9G212jLIS+Va87ugKuda8MYulXbU6NFBI5YIQy56VbBy5bS3N28y/xOKmr1bl
# Qd59QMuRGiWQexq/AfWhCZnP4N6SQQFPthYQKF0BHq7t/rjv5VATLuuXJff7oqeM
# 3XmvN4kUWGH0ejGmjtjaAs/V3t52rYe17ippwWwZVmdtwmPf186xEwg2UiDr8v8G
# MYE5oE9Dysp9jBI4hZMgfxfvlC45hmjQioPbcmjYq+oDrEKpOwtzPoZcO0Pj/grH
# lb9LuH4y8ZQNcZCDDp3GOozU2/S7hXklKShbGDnVkKhLkjHUJJ79zlE6krj/z9nw
# rQvIx6cwFv+dvvilQJAI1Ka4jFfyn85piix87RYqr2TFhmMwvVtSuhiCsTHPE0X9
# 3Q/uGZh+XkNB/EKhrLBFAjIgqmqXjTIILm72OMTh4SoR2xrzoo/p1GRYgEgbxLPG
# gNExeMEkfV0zRerJMshuu1wCv+dGggoIWgODI+uqpEQiFKSJ3zSPZGhmToYxAmMx
# W2H2AuUcF1SCTKmceave1Wxq70zAS6qgOkt/DBlmtGNv1egTUHI+GDXNuHjx/Gff
# 73sPSjNtlT1Xe6vfCLpgYpFRcTGCG0Mwghs/AgEBMGowVjELMAkGA1UEBhMCUEwx
# ITAfBgNVBAoTGEFzc2VjbyBEYXRhIFN5c3RlbXMgUy5BLjEkMCIGA1UEAxMbQ2Vy
# dHVtIENvZGUgU2lnbmluZyAyMDIxIENBAhAjt54rD9+c9X2Vc88whsMLMA0GCWCG
# SAFlAwQCAQUAoIGSMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCYGCisGAQQBgjcCAQwxGDAWoBSAEgBDAGEA
# cABGAHIAYQBtAGUAWDAvBgkqhkiG9w0BCQQxIgQgziazexwaRaR47ccGCelyLae/
# qJgZFRVbA/ykpvVXlCUwDQYJKoZIhvcNAQEBBQAEggIAAELktIMrXw+1IOTgmYMj
# Wu+rVo61/tYR2h6F308wEGJG0RenXYo/TinTRgkChw68t3AzSfcdPIZEswSVzveT
# c6yOSfsxnapKe9NNK1Au/H3xrFHzj7GlbkPzjTswP3ij+b60wnWi+ZnNI/MnLgqz
# WWSVHfX6KSZDpt/DM34kSnEjWbIwkeF2Kn0FzJ3Z5SbQOdhZSYUZVlVKhtg+QHWC
# VrWyK5r2AQwh0tBewyAxIFnJrl6UGqxHSNFDGltHfGM8r2T/6MP7vYX4FAV6JcHg
# PWpmidib3WtmndwgvWWsB+3V2mXii0CCZBZtAwWOjRIb9w93sEAP83Ja8tcq1Ip6
# aMea/+N044By+eXlZq25I/C59qe8tQTrVoj5R/HAlDKfADo20E4Vzl/Umrdd1qkO
# WL6kaiqZq595obohYZgBmev93G8wSm7c+NWlbXFkn011J/ky6xAHA8pR3PBBTDUL
# euzeU+p1bL/9ODQD0vIyCHthVvjiPKf7qcs830xjQHj/kAYniozTcax4sv7HxRdh
# jync9mCeeMLpZ8tvOc3G7fW1tkLAhKsobMMOO0g2iBk6E4/xsR3MUTmWUkVIFj75
# KS1M42aq4QJS+EAYbyKiW/i8EoP0HDuqYKrvsnfFAXXJBkO1y6ROJM2y9t9xy3od
# rj5CdgEMQSn5FiBKxgF9bAehghgVMIIYEQYKKwYBBAGCNwMDATGCGAEwghf9Bgkq
# hkiG9w0BBwKgghfuMIIX6gIBAzENMAsGCWCGSAFlAwQCAjCBzgYLKoZIhvcNAQkQ
# AQSggb4EgbswgbgCAQEGCyqEaAGG9ncCBQELMDEwDQYJYIZIAWUDBAIBBQAEIAdW
# S6DyP+77SSwZoD4Zi+I0mdsYOfULVUS8x3hefyFWAgcKqHx2ROCpGA8yMDI2MTEx
# MTE5MjM1NlowAwIBAaBUpFIwUDELMAkGA1UEBhMCUEwxITAfBgNVBAoMGEFzc2Vj
# byBEYXRhIFN5c3RlbXMgUy5BLjEeMBwGA1UEAwwVQ2VydHVtIFRpbWVzdGFtcCAy
# MDI2oIITEDCCBoIwggRqoAMCAQICECjwd8EcNr3+X3QyR3AnLgMwDQYJKoZIhvcN
# AQEMBQAwVjELMAkGA1UEBhMCUEwxITAfBgNVBAoTGEFzc2VjbyBEYXRhIFN5c3Rl
# bXMgUy5BLjEkMCIGA1UEAxMbQ2VydHVtIFRpbWVzdGFtcGluZyAyMDIxIENBMB4X
# DTI2MDMxMTA3MzQ1NFoXDTM2MDIyNzA3MzQ1NFowUDELMAkGA1UEBhMCUEwxITAf
# BgNVBAoMGEFzc2VjbyBEYXRhIFN5c3RlbXMgUy5BLjEeMBwGA1UEAwwVQ2VydHVt
# IFRpbWVzdGFtcCAyMDI2MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# uL3N8HD7EjXaGLYX241AE05JORMiLXd+6HcOJbJsjnf3ZsF8nDq07vMOztSo/+t6
# NV/jEVNTdc04+y44WQ/lI8WydbCfdUkv42E2Gy66O9ixC1pCe82jXCTjqt5ODCzU
# vw4UR0prGDKpPjM5DHzWYvA1lKpc1T1Gtv2gAlYkXgzJ3P4LV5u7QPT6+Aze2oBD
# xNTbTd+qAoI+oh0eWhoWof17JH7y2embLaGec3n1k62ay4d5HB/mJM6GWF/R3+qq
# q4s5IgY+AZUvUePlcFSjHY4Tu1BGv6X/HE1svo67AE7gBrYRu7FiDftyle/mLb+V
# Mvg0BIH925/1bh+MDdGj4Y/5sLnifY5iIzcKrzP3Z6PHwXkdY7Z7j/vl4L3kH20z
# D96rvXT0YPJbb7a63kGfSjwxclMRGTLKy1ZupydSSiYD3up+IMLC+la44x19M6Sx
# d71L7EPE4loJuLJOK+A+6XFxP619BNFcGvlTC0+9z4g2dp84SKXNUcDXW2/6kdzK
# WvLEFzTxxSKF/+22qRlLRubHdXFBrLy6iFpOnT/8QID29gZbnVIp0kwmFe8rIh0E
# vLxZg1yFO3zJEhO/0B3GD0moa6OH5Oc/VtbdpCMW2USXtLOA14jw5UD8IkBZZS5F
# PcC71Og6kfL9+WuuSeE3iF4TDv/ogsy/gdKyPRhnii0CAwEAAaOCAVAwggFMMHUG
# CCsGAQUFBwEBBGkwZzA7BggrBgEFBQcwAoYvaHR0cDovL3N1YmNhLnJlcG9zaXRv
# cnkuY2VydHVtLnBsL2N0c2NhMjAyMS5jZXIwKAYIKwYBBQUHMAGGHGh0dHA6Ly9z
# dWJjYS5vY3NwLWNlcnR1bS5jb20wHwYDVR0jBBgwFoAUvlQCL79AbHNDzqwJJU6e
# Q0Qa7uAwDAYDVR0TAQH/BAIwADA5BgNVHR8EMjAwMC6gLKAqhihodHRwOi8vc3Vi
# Y2EuY3JsLmNlcnR1bS5wbC9jdHNjYTIwMjEuY3JsMBYGA1UdJQEB/wQMMAoGCCsG
# AQUFBwMIMA4GA1UdDwEB/wQEAwIHgDAiBgNVHSAEGzAZMAgGBmeBDAEEAjANBgsq
# hGgBhvZ3AgUBCzAdBgNVHQ4EFgQUIzlqKKuaEqekp/If+UWav43+ggMwDQYJKoZI
# hvcNAQEMBQADggIBAGb+k5usC95OpgU8JK2HE1XAEdNbhN+4FBjYoYJ0yUfoAuNU
# 9h/ZcBE0YxNdJxHQlDb9zYvEumgceFHDEV/d33fcOEVLXrmtiPqI9JAqbjWtz0Ay
# lMKMx2ZqLVor2jzvSk7NPMtGFYVUjGb7lB/63hXnPXi0+hSwBZ19EoPVnO/N97kA
# eUT2vE5lwZE6JQvGzcR1/tknxFkjSPMP2O6PagRfZdLsFUq40IrVbSHWaNqm/Tbz
# KqjxS1mHn/UhvjxjKnzwENhKGHk9IZRS5Lm1hdV9x24g8F7c901NhFh1PlU3GTAu
# CMzMhyv/pIfZ96MUkOOcLGO9cu5qsSsmD8h0j6Fd0YgENU4a/XOuQXiS2hC8Vkin
# kMgBiHQbDJSFzzuqqflRphOPb6LKIENI2HtoYKuS4CeqDtCHt+uFf5CEwZ4n1Kku
# mcbvqo3zmEvKO9hHqBFiItOPwbh/GOpXjTT9u4/DSsGj3IlnKr/xwZ0I4s85h/2q
# l59Nytkp472mD5QkfHxQAFtpOqLNHGbyxRITJxxwIIWEiK3cAj/fAa5I4AN6IDrv
# o1xDv52w/Thi/O903ulNk3KDrvZakEMl2DR4i0eXjKia814g5aHWqzhCo5bpMjw5
# yyLi5INMuivEtQOcFPApDPOnF3VhRy0SBGHfZHQn0WQWR4Su4lT3hGWMWvW4MIIG
# uTCCBKGgAwIBAgIRAOf/acc7Nc5LkSbYdHxopYcwDQYJKoZIhvcNAQEMBQAwgYAx
# CzAJBgNVBAYTAlBMMSIwIAYDVQQKExlVbml6ZXRvIFRlY2hub2xvZ2llcyBTLkEu
# MScwJQYDVQQLEx5DZXJ0dW0gQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxJDAiBgNV
# BAMTG0NlcnR1bSBUcnVzdGVkIE5ldHdvcmsgQ0EgMjAeFw0yMTA1MTkwNTMyMDda
# Fw0zNjA1MTgwNTMyMDdaMFYxCzAJBgNVBAYTAlBMMSEwHwYDVQQKExhBc3NlY28g
# RGF0YSBTeXN0ZW1zIFMuQS4xJDAiBgNVBAMTG0NlcnR1bSBUaW1lc3RhbXBpbmcg
# MjAyMSBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOkSHwQ17bld
# esWmlUG+imV/TnfRbSV102aO2/hhKH9/t4NAoVoipzu0ePujH67y8iwlmWuhqRR4
# xLeLdPxolEL55CzgUXQaq+Qzr5Zk7ySbNl/GZloFiYwuzwWS2AVgLPLCZd5DV8QT
# F+V57Y6lsdWTrrl5dEeMfsxhkjM2eOXabwfLy6UH2ZHzAv9bS/SmMo1PobSx+vHW
# ST7c4aiwVRvvJY2dWRYpTipLEu/XqQnqhUngFJtnjExqTokt4HyzOsr2/AYOm8YO
# coJQxgvc26+LAfXHiBkbQkBdTfHak4DP3UlYolICZHL+XSzSXlsRgqiWD4MypWGU
# 4A13xiHmaRBZowS8FET+QAbMiqBaHDM3Y6wohW07yZ/mw9ZKu/KmVIAEBhrXesxi
# fPB+DTyeWNkeCGq4IlgJr/Ecr1px6/1QPtj66yvXl3uauzPPGEXUk6vUym6nZyE1
# IGXI45uGVI7XqvCt99WuD9LNop9Kd1LmzBGGvxucOo0lj1M3IRi8FimAX3krunSD
# guC5HgD75nWcUgdZVjm/R81VmaDPEP25Wj+C1reicY5CPckLGBjHQqsJe7jJz1CJ
# XBMUtZs10cVKMEK3n/xD2ku5GFWhx0K6eFwe50xLUIZD9GfT7s/5/MyBZ1Ep8Q6H
# +GMuudDwF0mJitk3G8g6EzZprfMQMc3DAgMBAAGjggFVMIIBUTAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBS+VAIvv0Bsc0POrAklTp5DRBru4DAfBgNVHSMEGDAW
# gBS2oVQ5AsOgP46KvPrU+Bym0ToO/TAOBgNVHQ8BAf8EBAMCAQYwEwYDVR0lBAww
# CgYIKwYBBQUHAwgwMAYDVR0fBCkwJzAloCOgIYYfaHR0cDovL2NybC5jZXJ0dW0u
# cGwvY3RuY2EyLmNybDBsBggrBgEFBQcBAQRgMF4wKAYIKwYBBQUHMAGGHGh0dHA6
# Ly9zdWJjYS5vY3NwLWNlcnR1bS5jb20wMgYIKwYBBQUHMAKGJmh0dHA6Ly9yZXBv
# c2l0b3J5LmNlcnR1bS5wbC9jdG5jYTIuY2VyMDkGA1UdIAQyMDAwLgYEVR0gADAm
# MCQGCCsGAQUFBwIBFhhodHRwOi8vd3d3LmNlcnR1bS5wbC9DUFMwDQYJKoZIhvcN
# AQEMBQADggIBALiTWXfJTBX9lAcIoKd6oCzwQZOfARQkt0OmiQ390yEqMrStHmpf
# ycggfPGlBHdMDDYhHDVTGyvY+WIbdsIWpJ1BNRt9pOrpXe8HMR5sOu71AWOqUqfE
# IXaHWOEs0UWmVs8mJb4lKclOHV8oSoR0p3GCX2tVO+XF8Qnt7E6fbkwZt3/AY/C5
# KYzFElU7TCeqBLuSagmM0X3Op56EVIMM/xlWRaDgRna0hLQze5mYHJGv7UuTCOO3
# wC1bzeZWdlPJOw5v4U1/AljsNLgWZaGRFuBwdF62t6hOKs86v+jPIMqFPwxNJN/o
# u22DqzpP+7TyYNbDocrThlEN9D2xvvtBXyYqA7jhYY/fW9edUqhZUmkUGM++Mvz9
# lyT/nBdfaKqM5otK0U5H8hCSL4SGfjOVyBWbbZlUIE8X6XycDBRRKEK0q5JTsaZk
# soKabFAyRKJYgtObwS1UPoDGcmGirwSeGMQTJSh+WR5EXZaEWJVA6ZZPBlGvjgjF
# YaQ0kLq1OitbmuXZmX7Z70ks9h/elK0A8wOg8oiNVd3o1bb59ms1QF4OjZ45rkWf
# sGuz8ctB9/leCuKzkx5Rt1WAOsXy7E7pws+9k+jrePrZKw2DnmlNaT19QgX2I+hF
# tvhC6uOhj/CgjVEA4q1i1OJzpoAmre7zdEg+kZcFIkrDHgokA5mcIMK1MIIFyTCC
# BLGgAwIBAgIQG7WPJSrfIwBJKMmuPX7tJzANBgkqhkiG9w0BAQwFADB+MQswCQYD
# VQQGEwJQTDEiMCAGA1UEChMZVW5pemV0byBUZWNobm9sb2dpZXMgUy5BLjEnMCUG
# A1UECxMeQ2VydHVtIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MSIwIAYDVQQDExlD
# ZXJ0dW0gVHJ1c3RlZCBOZXR3b3JrIENBMB4XDTIxMDUzMTA2NDMwNloXDTI5MDkx
# NzA2NDMwNlowgYAxCzAJBgNVBAYTAlBMMSIwIAYDVQQKExlVbml6ZXRvIFRlY2hu
# b2xvZ2llcyBTLkEuMScwJQYDVQQLEx5DZXJ0dW0gQ2VydGlmaWNhdGlvbiBBdXRo
# b3JpdHkxJDAiBgNVBAMTG0NlcnR1bSBUcnVzdGVkIE5ldHdvcmsgQ0EgMjCCAiIw
# DQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL35ePjm1YAMZJ2GG5ZkZz8iOh51
# AX3v+1xnjMnMXGupkea5QuUgS5vam3u5mV3Zm4BL14RAKyfT6Lowuz4JGqdJle8r
# QCTCl8en7psl76gKAJeFWqqd3CnJ4jUH63BNStbBs1a4oUE4m9H7MX+P4F/hsT8P
# jhZJYNcGjRj5qiYQqyrT0NFnjRtGvkcw1S5y0cVj2udjeUR+S2MkiYYuND8pTFKL
# KqfA4pEoibnAW/kd2ecnrf+aApfBxlCSmwIsvam5NFkKv4RK/9/+s5/r2Z7gmCPs
# pmt3FirbzK07HKSH3EZzXhliaEVX5JCCQrtC1vBh4MGjPWajXfQY7ojJjRdFKZky
# dQIx7ikmyGsC5rViRX83FVojaInUPt5OJ7DwQAy8TRfLTaKzHtAGWt32k89XdZn1
# +oYaZ3izv5b+NNy951JW5bPldXvXQZEF3F1p45UNQ7n8g5Y5lXtsgFpPE3LG130p
# ekS6UqQq1UFGCSD+IqC2WzCNvIkM1ddw+IdS/drvrFEuB7NO/tAJ2nDvmPpW5m3b
# tVdL3OUsJRXIni54TvjanJ6GLMpX8xrlyJKLGoKWesO8UBJp2A5aRos66yb6I8m2
# sIG+QgCk+Nb+MC7H0kb25Y51/fLMudCHW8wGEGC7gzW3XmfeR+yZSPGkoRX+rYxi
# jjlVTzkWubFjnf+3AgMBAAGjggE+MIIBOjAPBgNVHRMBAf8EBTADAQH/MB0GA1Ud
# DgQWBBS2oVQ5AsOgP46KvPrU+Bym0ToO/TAfBgNVHSMEGDAWgBQIds3LB/8k9sXN
# 7buQvOKEN0Z19zAOBgNVHQ8BAf8EBAMCAQYwLwYDVR0fBCgwJjAkoCKgIIYeaHR0
# cDovL2NybC5jZXJ0dW0ucGwvY3RuY2EuY3JsMGsGCCsGAQUFBwEBBF8wXTAoBggr
# BgEFBQcwAYYcaHR0cDovL3N1YmNhLm9jc3AtY2VydHVtLmNvbTAxBggrBgEFBQcw
# AoYlaHR0cDovL3JlcG9zaXRvcnkuY2VydHVtLnBsL2N0bmNhLmNlcjA5BgNVHSAE
# MjAwMC4GBFUdIAAwJjAkBggrBgEFBQcCARYYaHR0cDovL3d3dy5jZXJ0dW0ucGwv
# Q1BTMA0GCSqGSIb3DQEBDAUAA4IBAQBRwqFYFiIQi/yGMdTCMtNc+EuiL2o+Tfir
# CB7t1ej65wgN7LfGHg6ydQV6sQv613RqAAYfpM6q8mt92BHAEQjUDk1hxTqo+rHh
# 45jq4mP9QfWTfQ28XZI7kZplutBfTL5MjWgDEBbV8dAEioUz+TfnWy4maUI8us28
# 1HrpTZ3a50P7Y1KAhQTEJZVV8H6nnwHFWyj44M6GcKYnOzn7OC6YU2UidS3X9t0i
# IpGW691o7T+jGZfTOyWI7DYSPal+zgKNBZqSpyduRbKcYoY3DaQzjteoTtBKF0NM
# xfGnbNIeWGwUUX6KVKH27595el2BmhaQD+G78UoA+fndvu2q7M4KMYID7zCCA+sC
# AQEwajBWMQswCQYDVQQGEwJQTDEhMB8GA1UEChMYQXNzZWNvIERhdGEgU3lzdGVt
# cyBTLkEuMSQwIgYDVQQDExtDZXJ0dW0gVGltZXN0YW1waW5nIDIwMjEgQ0ECECjw
# d8EcNr3+X3QyR3AnLgMwDQYJYIZIAWUDBAICBQCgggFWMBoGCSqGSIb3DQEJAzEN
# BgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjYxMTExMTkyMzU2WjA3Bgsq
# hkiG9w0BCRACLzEoMCYwJDAiBCCFvpDhCtJDjXzJKLavSLCasggXfOz4sBJsWNOR
# BSXEPDA/BgkqhkiG9w0BCQQxMgQw/RwUoClZ9DsxScLiEefVjmw1bTmYfubPLeDu
# IPIcjrlorOEQZA23W5GIlmD1vDHWMIGfBgsqhkiG9w0BCRACDDGBjzCBjDCBiTCB
# hgQUVxRoQQyoWvNCTvkWSlE2EPTTjZgwbjBapFgwVjELMAkGA1UEBhMCUEwxITAf
# BgNVBAoTGEFzc2VjbyBEYXRhIFN5c3RlbXMgUy5BLjEkMCIGA1UEAxMbQ2VydHVt
# IFRpbWVzdGFtcGluZyAyMDIxIENBAhAo8HfBHDa9/l90MkdwJy4DMA0GCSqGSIb3
# DQEBAQUABIICAHOL5AFNheMiwGgrM13YwToPZZ7F2jAa+YDj+KS8W8CJhLDq58mk
# Ua3EeIFWKJU2C6DNijPFd2f4tmvgUcHjCZR/++RXm0qnkvH41EwjII+SZuNSa2Fr
# mj7UQxtIipFy20G+giglHO21cckoF9wgnpKYpQXUaMPR+RhZRIAzeINd8V92O5bc
# zneDUQ9s74vfJWR33rMfdOlEvNvqbqVlR3nPLZ9whxJcNRCU0b426sQSNa2YZPmF
# D3wMTCLPvwrgGTSohkb3nNQTOevjjjGO2sX+p33IIBY7/W678UTnD/iPFaClm+Ty
# 9JLRWkN31pTU4WGwkUKcmkZjmKYDKfNi4IUCQuJskXiPfWCy181PjNkybvmI5rib
# V0zVUsEzvjZnrXgiL2cm47Fu5UXbWcuTT5I73c4LtXfFVvP5wysWffdbjlBVt5Bm
# +GU/BU9WNd6ZTNZRgFlnk3cPMbbH8ktwXkE8UecP2qy1AByQ1jXOPFeInZkwWYij
# IVmDQyu+aVLCa/tJrm1Jba+SEENJnfD8J3VF2ww4iRWtV8bZJQEevY8lcs7XY6JE
# Qxrlhnpl1mtFOtusL2NWSdSdlxqTgMiiK6sN03m5vP8mOj047HqMylzScYULkj64
# qmxeN6h5x3zyFjctdXigmYnCCnh2AKU1ZNVvFrXiDzkyeIyzaMnHQ9ko
# SIG # End signature block
